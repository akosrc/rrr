#pragma once

// WE SUPPORT FUN  (4.6.0) SDKGen by @O_N_E_B_I_E_C_E | @onebiecerr 
// Send Message Me For SDKGen Tool  
// Generate on Tue Sep  8 20:36:04 2026
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// AnimBlueprintGeneratedClass CH_Base_AnimBP_MainCity_TPP.CH_Base_AnimBP_MainCity_TPP_C
// 0x1A60 (0x3330 - 0x18D0)
class UCH_Base_AnimBP_MainCity_TPP_C : public UCharMainMCAnimInstance
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x18D0(0x0008) (Transient, DuplicateTransient)
	struct FAnimNode_Slot                              AnimGraphNode_Slot_95EC37444D2783028D0509B3D2BC31DA;      // 0x18D8(0x0070)
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_33BBAA8F44ABFE1314FE938843BD045F;// 0x1948(0x00C0)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_61316C7E46619171838C3F963F405D2A;// 0x1A08(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_76B99DC84072BA3C0786C29E9E29BB65;// 0x1A50(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_4B9202814EAEE5E8C6F84BBCA2B779F3;// 0x1A98(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_895296D24A9F7A856166378E952F6B69;// 0x1AE0(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_A1EFD8F1495CE7BAD195DDB44A756B68;// 0x1B28(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_FE062345416B64A640EA20B26FCCADD2;// 0x1B70(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_1CA6B8D5497E74E6F43CAEB6DDEFBBC5;// 0x1BB8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_1873132544FC0C24E6E9D78009A10781;// 0x1C00(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_9E88F58F4AB6EE52BA9A69BFC886550A;// 0x1C48(0x0048)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_848561B04A016AA68BCBBE8EFFA343FD;// 0x1C90(0x0128)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_4F9BC4314BE4DA84F20AD4A27AAC395A;// 0x1DB8(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_FFF262E84F13F43A0FDF44A2F37CA696;// 0x1E08(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_9D9D8FCC441A7F05532D81BE6C797E4A;// 0x1E78(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_5DD0B0D24ED85ACF9D4CB39EE7DC6F51;// 0x1EC8(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_6E1D113D4A61E2CDD8D86989D7072B12;// 0x1F38(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_06F8D9E54D6A670C97160781AAC21798;// 0x1F88(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_A5BBC01C4E35430A5EA3F7B595589567;// 0x1FF8(0x0050)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_4F5E39D64276B82ED0F85587898EA736;// 0x2048(0x0058)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_1CF150234CC2C8D35D381F9C7E447C27;// 0x20A0(0x0070)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_EC58EF22440F5629E656CCACAAC6425B;// 0x2110(0x00D0)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_C489CE0542F69637F4FF2A8E70E7FF28;// 0x21E0(0x0070)
	struct FAnimNode_ApplyAdditive                     AnimGraphNode_ApplyAdditive_6BCD08EB410E000767F30D81197CD228;// 0x2250(0x0080)
	struct FAnimNode_RotateRootBone                    AnimGraphNode_RotateRootBone_3379463249DB5026719BCDA500803EDE;// 0x22D0(0x0068)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_B02F45DC49034869CCF72E8A45EDDEDA;// 0x2338(0x0050)
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_B67104D44ACE002A28E6C59C9001EE5A;// 0x2388(0x00D8)
	struct FAnimNode_Slot                              AnimGraphNode_Slot_4EC4E5F3433702D6A993089DD613B5AA;      // 0x2460(0x0070)
	struct FAnimNode_LayeredBoneBlend                  AnimGraphNode_LayeredBoneBlend_B8BB26944D9EAC6456923CB5DA53168E;// 0x24D0(0x00E8)
	struct FAnimNode_Slot                              AnimGraphNode_Slot_1C9142144003EF79A3FF3882AC6BD71A;      // 0x25B8(0x0070)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_09469ACD4053F9462C5C3FA079746818;// 0x2628(0x00D0)
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_0EDC83854E6532859A698DA8FAA223B3;// 0x26F8(0x00C0)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_B26849D94D98F246150DB3B5254FFE0F;// 0x27B8(0x0058)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_0E7FDF5D4A5B2417CBCFD0A80DF3AE8B;// 0x2810(0x0058)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_125A562843C0C4FBD9B9DAAFAB82F834;// 0x2868(0x0058)
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_835206744B1115E35B53278B35ABBBF0;// 0x28C0(0x00C0)
	struct FAnimNode_Slot                              AnimGraphNode_Slot_DB6B3DFA4FD15B2604FE679CDAB849F9;      // 0x2980(0x0070)
	struct FAnimNode_BlendListByEnumAdvance            AnimGraphNode_BlendListByEnumAdvance_2F85DDD4439D6AC83CDEFCAA8ADCC6E0;// 0x29F0(0x00F8)
	struct FAnimNode_Slot                              AnimGraphNode_Slot_89E0DE5E46485E04CDF60A9F236DA1F9;      // 0x2AE8(0x0070)
	struct FAnimNode_ConvertLocalToComponentSpace      AnimGraphNode_LocalToComponentSpace_26A9200640DB38F809204BAF119687E3;// 0x2B58(0x0050)
	struct FAnimNode_ConvertComponentToLocalSpace      AnimGraphNode_ComponentToLocalSpace_311D18DF4EEC152C513A66BFF2CA60C3;// 0x2BA8(0x0050)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_71DA3A28400B4A1791A9BBBBFB374409;// 0x2BF8(0x00C0)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_C6EC376C47FC1946B476B89CFD7AE2E2;// 0x2CB8(0x0058)
	struct FAnimNode_AnimInstanceContainer             AnimGraphNode_AnimInstanceContainer_58BEE2C343A11CD805F0CEAEB2669FDE;// 0x2D10(0x0098)
	struct FAnimNode_Root                              AnimGraphNode_Root_F17603FF4C45548C8ECEEB9825890D0C;      // 0x2DA8(0x0050)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_9C7680144809F374A3ECDEB605A6DFA5;// 0x2DF8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_276B8A6E4849011CC43D74BE513D5D67;// 0x2E40(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_0711472B4AB410F69CEB17B8D446FE84;// 0x2E88(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_52B6FA714412F66DBF7662B5B3C9F68D;// 0x2ED0(0x0048)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_CA34E19646F8F7246E801490D9A50514;// 0x2F18(0x0058)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_773C778646FD5FE40EAA4F9EF41163ED;// 0x2F70(0x0050)
	struct FAnimNode_AnimInstanceContainer             AnimGraphNode_AnimInstanceContainer_28A00FFE4AD18CFA8F7A4EABD34054C3;// 0x2FC0(0x0098)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_6BF56DAA497D92AB3AB118BCB03FE51A;// 0x3058(0x0050)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_13317A20404CC7DB24D990BC785C1594;// 0x30A8(0x0058)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_663C7ED241FE57E0B0C2549F38609B04;// 0x3100(0x0050)
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_6BDF46C2426A99A12D87ADA623923289;// 0x3150(0x00D8)
	struct FAnimNode_Slot                              AnimGraphNode_Slot_4DFF26E94B946D1CC43CB3ADBCBC5195;      // 0x3228(0x0070)
	struct FAnimNode_Slot                              AnimGraphNode_Slot_F2B40EF4412D46DA0EE231B0B9A13F0A;      // 0x3298(0x0070)
	struct FAnimContainer                              MotionOverLayer;                                          // 0x3308(0x0028) (Edit, BlueprintVisible, DisableEditOnInstance)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("AnimBlueprintGeneratedClass CH_Base_AnimBP_MainCity_TPP.CH_Base_AnimBP_MainCity_TPP_C");
		return pStaticClass;
	}


	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_SequencePlayer_06F8D9E54D6A670C97160781AAC21798();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_9E88F58F4AB6EE52BA9A69BFC886550A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_BlendListByBool_EC58EF22440F5629E656CCACAAC6425B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_SequencePlayer_C489CE0542F69637F4FF2A8E70E7FF28();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_ApplyAdditive_6BCD08EB410E000767F30D81197CD228();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_RotateRootBone_3379463249DB5026719BCDA500803EDE();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_1873132544FC0C24E6E9D78009A10781();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_BlendListByBool_09469ACD4053F9462C5C3FA079746818();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_BlendListByEnumAdvance_2F85DDD4439D6AC83CDEFCAA8ADCC6E0();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_AnimInstanceContainer_58BEE2C343A11CD805F0CEAEB2669FDE();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_9C7680144809F374A3ECDEB605A6DFA5();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_276B8A6E4849011CC43D74BE513D5D67();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_1CA6B8D5497E74E6F43CAEB6DDEFBBC5();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_0711472B4AB410F69CEB17B8D446FE84();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_52B6FA714412F66DBF7662B5B3C9F68D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_FE062345416B64A640EA20B26FCCADD2();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_AnimInstanceContainer_28A00FFE4AD18CFA8F7A4EABD34054C3();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_A1EFD8F1495CE7BAD195DDB44A756B68();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_895296D24A9F7A856166378E952F6B69();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_BlendSpacePlayer_848561B04A016AA68BCBBE8EFFA343FD();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_4B9202814EAEE5E8C6F84BBCA2B779F3();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_SequencePlayer_5DD0B0D24ED85ACF9D4CB39EE7DC6F51();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_76B99DC84072BA3C0786C29E9E29BB65();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_SequencePlayer_FFF262E84F13F43A0FDF44A2F37CA696();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_61316C7E46619171838C3F963F405D2A();
	void AnimNotify_PlayFallSound();
	void AnimNotify_SpawnLFootprint();
	void AnimNotify_SpawnRFootprint();
	void ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP(int EntryPoint);
};


}

